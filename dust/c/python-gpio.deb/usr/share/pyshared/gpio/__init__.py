#!/usr/bin/python
import os
path = "/sys/class/gpio/gpio"

class NotExported(Exception) :
    def __init__(self, pin) :
        print "ERROR: Pin %s has not been exported" % str(pin)
        exit(1)
class NotAllowed(Exception) :
    def __init__(self, pin) :
        print "ERROR: Unable to access pin %s" % str(pin)
        exit(1)
class WrongMode(Exception) :
    def __init__(self, mode) :
        print "ERROR: Mode %s unknown " % str(mode)
        exit(2)
class NotInitialized(Exception) :
    def __init__(self, pin) :
        print "ERROR: The mode for pin %s has not been set to 'out' or the 'value' file is not writable" % str(pin)
        exit(1)
class InvalidValue(Exception) :
    def __init__(self, value) :
        print "ERROR: Invalid value: %s. The output value has to be 1 or 0" % str(value)
        exit(2)
class NotReadable(Exception) :
    def __init(self, pin) :
        print "ERROR: The mode for pin %s has not been set to 'in' or the value file is not readable" % str(pin)
        exit(1)

def setmode(pin, mode) :
    direction_file = path + str(pin) + "/direction"
    if not os.path.exists(direction_file) :
        raise NotExported(pin)
    try :
        f = open(direction_file , "w")
    except :
        raise NotAllowed(pin)
    if not mode == "out" and not mode == "in" :
        raise WrongMode(mode)
    f.write(mode)
    f.close()
def output(pin, value) :
    value_path = path + str(pin) + "/value"
    if not os.path.exists(value_path) :
        raise NotExported(pin)
    try :
        f = open(value_path, "w")
    except :
        raise NotInitialized
    try :
        if not int(value) == 1 and not int(value) == 0 :
            raise InvalidValue(value)
    except :
        raise InvalidValue(value)
    f.write(str(int(value)))
    f.close()
def input(pin) :
    value_path = path + str(pin) + "/value"
    if not os.path.exists(value_path) :
        raise NotExported(pin)
    try :
        f = open(value_path, "r" )
    except :
        raise NotReadable(pin)
    value = int(f.read(1))
    f.close()
    return value
